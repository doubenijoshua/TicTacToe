package com.example.jbutter.tic_tac_toe;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button[][] board = new Button[3][3];
    private Button restButton, exitButton;
    private TextView moveTextView;
    private int roundCount;
    private boolean winnerFound;
    private AlertDialog.Builder dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dialog = new AlertDialog.Builder(this);

        moveTextView = (TextView) findViewById(R.id.moveTextView);
        restButton = (Button) findViewById(R.id.reset_button);
        exitButton = (Button) findViewById(R.id.exit_button);

        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetBoard();
                finish();
                System.exit(0);
            }
        });

        restButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetBoard();
            }
        });

        for (int i = 0; i < 3; i++) {

            for (int j = 0; j < 3; j++) {

                int resId = getResources().getIdentifier("button" + i + j, "id", getPackageName());

                board[i][j] = (Button) findViewById(resId);
                board[i][j].setOnClickListener(this);

            }

        }

        computerTurn();
        roundCount = 1;

        moveTextView.setText("Human Turn");
    }

    private void draw() {

        winnerFound = false;
        roundCount = 1;

        dialog.setMessage("It's a draw");
        dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                return;
            }
        });

        dialog.show();
    }

    private void computerWins() {
        dialog.setMessage("Congratulation!!!\nComputer Wins");
        dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                moveTextView.setText("Please reset board");
                //resetBoard();
            }
        });

        dialog.show();
    }


    private void humanWins() {
        dialog.setMessage("Congratulation!!!\nHuman Wins");
        dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                moveTextView.setText("Please reset board");

            }
        });

        dialog.show();
    }

    private void resetBoard() {

        dialog.setMessage("Do you want to start new Game?");
        dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                for (int i = 0; i < 3; i++) {

                    for (int j = 0; j < 3; j++) {

                        board[i][j].setText("");

                    }
                }
                computerTurn();
                winnerFound = false;
                moveTextView.setText("Human Turn");
            }
        });

        dialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                return;
            }
        });

        dialog.show();

    }

    private boolean checkForWin() {

        String[][] field = new String[3][3];

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {

                field[i][j] = board[i][j].getText().toString();

            }
        }
        for (int i = 0; i < 3; i++) {
            if (field[i][0].equals(field[i][1]) && field[i][0].equals(field[i][2])
                    && !field[i][0].equals("")) {
                return true;
            }
        }

        for (int i = 0; i < 3; i++) {
            if (field[0][i].equals(field[1][i]) && field[0][i].equals(field[2][i])
                    && !field[0][i].equals("")) {
                return true;
            }
        }

        if (field[0][0].equals(field[1][1]) && field[0][0].equals(field[2][2])
                && !field[0][0].equals("")) {
            return true;
        }

        if (field[0][2].equals(field[1][1]) && field[0][2].equals(field[2][0])
                && !field[0][2].equals("")) {
            return true;
        }

        return false;

    }

    private void computerTurn() {

        int rd = (int) (Math.random() * 9);

        final int i = rd / 3;
        final int j = rd % 3;

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                if (!(board[i][j].getText().equals("O")) &&
                        !(board[i][j].getText().equals("X"))) {

                    board[i][j].setText("X");
                    roundCount += 1;
                    moveTextView.setText("Human Turn");
                    if (checkForWin()) {
                        computerWins();
                        winnerFound = true;
                    }

                } else {
                    computerTurn();
                }
            }
        }, 10);

        if (roundCount == 9)
            draw();

        //Log.e("Count play", "" + roundCount);

    }

    @Override
    public void onClick(View v) {
        roundCount += 1;

        ((Button) v).setText("O");
        moveTextView.setText("Computer Turn");

        if (roundCount == 9)
            draw();

        if (checkForWin()) {
            humanWins();
            winnerFound = true;
        }

        if (winnerFound == false) {

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {

                    computerTurn();

                }
            }, 1000);


        }

    }
}
